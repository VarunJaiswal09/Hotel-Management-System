package Hotel_Management;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;


public class Hotel extends JFrame implements ActionListener
{
	Hotel()
	{
		//setSize(4288,2848);
		//setLocation(100,100);
		setBounds(0,0,2000,1553);
		setLayout(null);
		setVisible(true);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("photo2.jpg"));
		JLabel image = new JLabel(i1);
		image.setBounds(0,0,2000,1553);
		add(image);
		
		JLabel text = new JLabel("HOTEL MANAGEMENT SYSTEM");
		text.setBounds(70,700,700,60);
		text.setForeground(Color.WHITE);
		text.setFont(new Font("serif",Font.PLAIN,30));
		image.add(text);
		
		JButton next = new JButton("next");
		next.setBounds(1300,700,150,50);
		next.setBackground(Color.white);
		next.setForeground(Color.black);
		next.addActionListener(this);
		next.setFont(new Font("serif",Font.PLAIN,28));
		image.add(next);
		
		while(true)
		{
			text.setVisible(false);
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			text.setVisible(true);
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		setVisible(false);
		new login();
	}

	public static void main(String[] args) 
	{
		new Hotel();

	}

}
